/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package clientserveer;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.StringTokenizer;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author amir et wilfrield
 */
public class CGUI extends javax.swing.JFrame implements Runnable{

    /**
     * Creates new form CGUI
     */
    Socket socket;
    DataOutputStream dout;
    DataInputStream din;
    ///////////////////////////
    
    /**element graphique**/
    Thread t=null;
    
    /**element Personnel**/
    String USERNAME;
    String MSGTYPE="";
    static String HOST="";
    static int PORT=0;
    static ArrayList<String> USERNAMES = new ArrayList<String>();
    static ArrayList<String> DEST = new ArrayList<String>();

    public CGUI(String USERNAME,String host,int port) throws IOException 
    {
        PORT =port;
        HOST = host;
        initComponents();
        
        socket=new Socket(HOST ,PORT);

        din=new DataInputStream(socket.getInputStream()); 
        dout=new DataOutputStream(socket.getOutputStream()); 
        //Annoncer le Usernme au ClientHandler
        dout.writeUTF(USERNAME);
        //recuperer le username generer par le ClientHandler
        this.USERNAME=din.readUTF();
        this.setTitle(this.USERNAME);
        t=new Thread(this);
        t.start();
    }

    /*****methode pour verrifier si laconnexion avec le server esttoujrs valide **/
private static boolean availableServerConnection() {
    try (ServerSocket ignored = new ServerSocket(PORT)) {
        return false;
    } catch (IOException ignored) {
        return true;
    }
}
    
    
    
    
    public void SEND()
    {
            try
            {
                if(availableServerConnection()==false){
                    JOptionPane.showMessageDialog(null, "Connecxion perdue! le serveur est deconnecte","Erreur", JOptionPane.CLOSED_OPTION); 
                    System.exit(1);}
                
                MSGTYPE="MSG";
            int row = jTable1.getSelectedRow();
            for(int i=0;i<jTable1.getModel().getRowCount();i++)
                //selection des destinataires
                if(jTable1.getModel().getValueAt(i, 0).equals(true))
                    DEST.add(jTable1.getModel().getValueAt(i, 1).toString());
            
            	///////////////type du msg //// sendto ///////////////////sentfrom ////////////////////// message
            	dout.writeUTF( MSGTYPE + " "  + DEST + " 10110110101 "  + USERNAME+ " 10110110101 "  + CGUI.jTextField1.getText().toString());            
                CGUI.jTextArea1.append("\n" + USERNAME + " Says:" + CGUI.jTextField1.getText().toString()+" to "+DEST);    
                CGUI.jTextField1.setText("");
                //vider la liste desdestination apres envoi
                DEST.clear();
            }
            catch(Exception ex)
            {
            }    
    }
        
        //////////////////// demande de Pull PDU
   public void LIST()
    {
            try
            {  	MSGTYPE="LIST";
            if(availableServerConnection()==false){
                    JOptionPane.showMessageDialog(null, "Connecxion perdue! le serveur est deconnecte", 
                            "Pulling impossible", JOptionPane.CLOSED_OPTION); 
                            System.exit(1);}

        	////////type du msg //////////sendto /////////////////////sentfrom ////////////////message
                dout.writeUTF( MSGTYPE + " "  + "SERVER" +" 10110110101 "  + USERNAME+" 10110110101 "  + null);            
                CGUI.jTextArea1.append("\n" + USERNAME + " Plling...:");    
                CGUI.jTextField1.setText("");
            }
            catch(Exception ex)
            {
            }    
    }
        
        
        
   public void CLOSE()
    {
            try
            {
                if(availableServerConnection()==false){
                    JOptionPane.showMessageDialog(null, "Connecxion perdue! le serveur est deconnecte : le LOGOUT ne sera pas envoyer au ClientHandler", 
                            "Deconexion", JOptionPane.CLOSED_OPTION); 
                System.exit(1);}
                
                
            	MSGTYPE="LOGOUT";
        	    //////////type du msg //////sendto /////////////////////sentfrom ///////////////////message            	
                dout.writeUTF( MSGTYPE + " "  + "SERVER" +" 10110110101 "  + USERNAME+" 10110110101 "  + null); 
                CGUI.jTextArea1.append("\n"+ " loging out...:"); 
                System.exit(1);
            }
            catch(Exception ex)
            {
            }
            
    }
    
    
        public static void main(String USERNAME,String Host,int port) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(CGUI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(CGUI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(CGUI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(CGUI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    if(USERNAME==null || Host==null || port==0)
                        JOptionPane.showMessageDialog(null, "Connecxion Impossible avec des champs vide!", 
                            "Deconexion", JOptionPane.CLOSED_OPTION);
                    else
                    new CGUI(USERNAME,Host,port).setVisible(true);
                } catch (IOException ex) {
                }
            }
        });
    }
   
   
   public  void run()
    {        
        while(true)
        {
            try
            {    String msg=new String(); 
            //recevoir le mssage en entier
            	msg=din.readUTF();
            	StringTokenizer st=new StringTokenizer(msg);
                //lire le type du msg
                String MsgType=st.nextToken();                
                //lire le username destinataire
                String Sendto=st.nextToken(); 
                //-----lire le separateur-----------
                String ENDDEST=st.nextToken(); 
                //-----lire le username de l'emeteur-----------
                String SendFrom=st.nextToken();
                 //-----lire le separateur-----------
                String ENDFROM=st.nextToken();
                String message="";
                //lire le message
                while(st.hasMoreTokens())
                {
                	message=message+" " +st.nextToken();
                }
 
                if(MsgType.equals("LIST")) {
                    String tmp = message.replace("["," ");String tmp2 = tmp.replace("]"," ");message = tmp2.replace(","," ");
                    StringTokenizer msgToken=new StringTokenizer(message);
                    //vider la list des usernames
                    USERNAMES.clear();
                    
                    DefaultTableModel model =(DefaultTableModel)jTable1.getModel();
                    model.setRowCount(0); 
                    //ajouer la nouvel liste
                    while(msgToken.hasMoreTokens())USERNAMES.add(msgToken.nextToken());
                    //les affiche sur l'interface
                    for(String s : USERNAMES)model.addRow(new Object[]{ false,""+s});
                    
                	CGUI.jTextArea1.append( "\n" +" Users :" + message);
                	}
                	
                	if(MsgType.equals("MSG")) {
                    CGUI.jTextArea1.append( "\n" + SendFrom + " Says :" + message);
                	}
                
                
            }
            catch(Exception ex)
            {
                //ex.printStackTrace();
            }
        }
    }
   
   
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jScrollPane2 = new javax.swing.JScrollPane();
        jTextArea1 = new javax.swing.JTextArea();
        jPanel2 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jPanel3 = new javax.swing.JPanel();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();
        jPanel4 = new javax.swing.JPanel();
        jTextField1 = new javax.swing.JTextField();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jTextArea1.setColumns(20);
        jTextArea1.setRows(5);
        jScrollPane2.setViewportView(jTextArea1);

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane2))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 154, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null},
                {null, null},
                {null, null},
                {null, null}
            },
            new String [] {
                "SELECT", "CLIENT"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.Boolean.class, java.lang.String.class
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }
        });
        jScrollPane1.setViewportView(jTable1);

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 548, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 122, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(186, 186, 186))
        );

        jButton1.setText("SEND");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jButton2.setText("LIST");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        jButton3.setText("CLOSE");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(32, 32, 32)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jButton3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jButton2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jButton1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap(49, Short.MAX_VALUE))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jButton1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jButton2)
                .addGap(18, 18, 18)
                .addComponent(jButton3)
                .addContainerGap())
        );

        jTextField1.setText("jTextField1");

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel4Layout.createSequentialGroup()
                .addContainerGap(95, Short.MAX_VALUE)
                .addComponent(jTextField1, javax.swing.GroupLayout.PREFERRED_SIZE, 524, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jTextField1, javax.swing.GroupLayout.DEFAULT_SIZE, 26, Short.MAX_VALUE)
                .addContainerGap())
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(10, 10, 10)
                        .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, 140, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addContainerGap())))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        // TODO add your handling code here:
        SEND();
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        // TODO add your handling code here:
        LIST();
    }//GEN-LAST:event_jButton2ActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        // TODO add your handling code here:
        CLOSE();
    }//GEN-LAST:event_jButton3ActionPerformed

    /**
     * @param args the command line arguments
     */


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    public static javax.swing.JTable jTable1;
    public static javax.swing.JTextArea jTextArea1;
    public static javax.swing.JTextField jTextField1;
    // End of variables declaration//GEN-END:variables
}
