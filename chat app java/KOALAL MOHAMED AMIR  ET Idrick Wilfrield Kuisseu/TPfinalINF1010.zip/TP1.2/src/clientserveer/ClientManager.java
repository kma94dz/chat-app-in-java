package clientserveer;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.StringTokenizer;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

public class ClientManager extends Thread
{
	/////element reseau////////
    Socket ClientSocket;
    ServerSocket ServerS;
    DataInputStream din;
    DataOutputStream dout;
    
    /**element Personnel**/
	static ArrayList<String> USERNAMES = new ArrayList<String>();
	static ArrayList<String> DEST = new ArrayList<String>();
	static ArrayList<Socket> ClientSockets = new ArrayList<Socket>();
	


	ClientManager (Socket Socket) throws Exception
    {
        ClientSocket=Socket;
        din=new DataInputStream(ClientSocket.getInputStream());
        dout=new DataOutputStream(ClientSocket.getOutputStream());
        //reception de la demande USERNAME et concat avec la taille de la pile : exemple AMIR devient AMIR7
        String USERNAME=din.readUTF()+USERNAMES.size();
        dout.writeUTF(USERNAME);
        ////////////////////////////////////
        System.out.println("Un utilisateur c'est connecter: " + USERNAME);
        //ajout du username a la liste des usernames
        USERNAMES.add(USERNAME.replace(" ",""));
        //ajout de la socket du client a la liste des sockets
        ClientSockets.add(ClientSocket);   
        
        start();
    }

        /*****methode pour envoi de la list des user connecter**/
        public  void SENDLIST()
    {
        
        //donner au nouveau USER la list de tout les USERS connecter
    	for(int iCount=0;iCount<USERNAMES.size();iCount++)
        {
    		try
    			{
                Socket tSoc=(Socket)ClientSockets.get(iCount);                            
                DataOutputStream tdout=new DataOutputStream(tSoc.getOutputStream());
                ///////////////type du msg //////////// sendto /////////////////////////////sentfrom ////////////////////// message
                tdout.writeUTF("LIST" + " "  + USERNAMES.get(iCount) +  " 10110110101 "  + "SERVER" + " 10110110101 " +USERNAMES);  

    			}catch(Exception ex)
                {
                    ex.printStackTrace();
                }
        }
        
    }
        
        
    public  void run()
    {
        SENDLIST();
        while(true)
        {
             
            try
            {
                String msgFromClient=new String();
                //recevoir le mssage en entier
                msgFromClient=din.readUTF();
                StringTokenizer st=new StringTokenizer(msgFromClient);
                //lire le type du msg
                String MsgType=st.nextToken();
                
                //------lire le username destinataire----------
                while(st.hasMoreTokens()) {
                	String sr = st.nextToken();
                        //si on atteint le separateur
                        if(sr.equals("10110110101"))break;
                	String tmp = sr.replace("["," ");String tmp2 = tmp.replace("]"," ");sr = tmp2.replace(","," ");
                        DEST.add(sr);
                }
                
               
                StringBuilder sb = new StringBuilder();
                //-----lire le username de l'emeteur-----------
                while(st.hasMoreTokens()) {
                	String sr = st.nextToken();
                        if(sr.equals("10110110101"))break;
                        sb.append(sr);
                }
                //----------------
                String SendFrom=""+sb;

                int iCount=0;
    
                if(MsgType.equals("LOGOUT"))
                {
                    for(iCount=0;iCount<USERNAMES.size();iCount++)
                    {
                        if(USERNAMES.get(iCount).equals(SendFrom))
                        {
                            //suppression du username et de la socket dela liste
                            USERNAMES.remove(iCount);
                            ClientSockets.remove(iCount);
                            System.out.println("User " + SendFrom +" Logged Out ...");
                            //envoyerla nouvel list des usernames
                            SENDLIST();
                            break;
                        }
                    }
    
                }
                else if(MsgType.equals("MSG")) {                  
                    String msg="";
                    //lire le message
                    while(st.hasMoreTokens())msg=msg+" " +st.nextToken();
                    int destCount=0;
                    for(iCount=0;iCount<USERNAMES.size();iCount++)
                    {   
                    	for(destCount=0;destCount<DEST.size();destCount++) {
                        if( (USERNAMES.get(iCount).equals(DEST.get(destCount).replace(" ","") )) && (!DEST.get(destCount).replace(" ","").equals(SendFrom) ) )
                        {     
                            Socket tSoc=(Socket)ClientSockets.get(iCount);                            
                            DataOutputStream tdout=new DataOutputStream(tSoc.getOutputStream());
                            ///////////////type du msg //////////// sendto //////////////////////////sentfrom ///////////// message
                            tdout.writeUTF(MsgType + " "  + DEST.get(destCount) + " 10110110101 "  + SendFrom+ " 10110110101 "+ msg);  
                            break;
                        }
                    	}
                        
                    }
                    DEST.clear();

                }
                    else if(MsgType.equals("LIST")) {
                        for(iCount=0;iCount<USERNAMES.size();iCount++)
                        {
                            if(USERNAMES.get(iCount).equals(SendFrom))
                            {    
                                Socket tSoc=(Socket)ClientSockets.get(iCount);                            
                                DataOutputStream tdout=new DataOutputStream(tSoc.getOutputStream());
                             ///////////////type du msg /////// sendto //////////////////////sentfrom ///////////////// message                               
                                tdout.writeUTF("LIST" + " "  + SendFrom + " 10110110101 "  + "SERVER"+ " 10110110101 "+USERNAMES);                            
                                break;
                            }
                        }
                       
                if(iCount==USERNAMES.size())
                        {
                            dout.writeUTF("I am offline");
                        }
                        else
                        {
                            
                        }
                    }                
                if(MsgType.equals("LOGOUT"))
                {
                    break;
                }

            }
            catch(Exception ex)
            {
                ex.printStackTrace();
            }
            
            
            
        }        
    }

}